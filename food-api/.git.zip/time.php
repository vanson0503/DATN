<?php
echo "The time is " . date('l dS \of F Y h:i:s A');
?>